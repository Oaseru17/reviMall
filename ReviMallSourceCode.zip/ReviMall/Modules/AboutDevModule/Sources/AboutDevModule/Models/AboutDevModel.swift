//  AboutDevModel.swift
//  Created by Precious Osaro on 16.04.23.

import Foundation

struct AboutDevModel {
    let name: String
    let email: String
    let finishedDate: String
}
