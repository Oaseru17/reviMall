//  AboutDevView.swift
//  Created by Precious Osaro on 16.04.23.

import SwiftUI

struct AboutDevView: View {
    let model = AboutDevModel(name: "Precious Oaseru Osaro",
                          email: "JohnsonOaseru@gmail.com",
                          finishedDate: "Created on 4th Dec 2022")
    
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("DEVELOPER'S INFORMATION")) {
                    Text (model.name)
                        .font(.title)
                    Text (model.email)
                        .foregroundColor(Color.black)
                    Text (model.finishedDate)
                        .foregroundColor(Color.black)
                }
            }
        }
    }
}

struct AboutDevView_Previews: PreviewProvider {
    static var previews: some View {
        AboutDevView()
    }
}
