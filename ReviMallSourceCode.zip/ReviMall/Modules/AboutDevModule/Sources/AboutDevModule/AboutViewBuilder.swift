//  AboutViewBuilder.swift
//  Created by Precious Osaro on 16/04/2023.

import SwiftUI
import CoreModule

public class AboutViewBuilder: BaseViewBuilderProtocol {

    public init() {}
    
    @MainActor
    public func start() -> some View {
        AboutDevView()
    }
}
