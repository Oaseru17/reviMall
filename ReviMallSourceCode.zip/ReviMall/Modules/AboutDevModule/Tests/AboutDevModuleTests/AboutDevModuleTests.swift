import XCTest
@testable import AboutDevModule

final class AboutDevModuleTests: XCTestCase {
}
