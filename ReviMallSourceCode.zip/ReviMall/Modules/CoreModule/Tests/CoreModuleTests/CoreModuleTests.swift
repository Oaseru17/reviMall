import XCTest
@testable import CoreModule

final class CoreModuleTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(CoreModule().text, "Hello, World!")
    }
}
