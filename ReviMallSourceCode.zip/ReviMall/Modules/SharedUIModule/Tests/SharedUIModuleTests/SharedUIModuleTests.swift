import XCTest
@testable import SharedUIModule

final class SharedUIModuleTests: XCTestCase {
}
